// src\components\Header\index.jsx

import React from 'react';
import { Link } from 'react-router-dom';
import './styles.css';

const Header = () => {
  return (
    <header className="header-container">
      {/* Adicione este container interno */}
      <div className="header-container-inner">
        <div className="logo">
          <Link to="/"><img src="logo.svg" alt="Senai Farmacy" /></Link>
        </div>
        <nav className="nav-menu">
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/servicos">Serviços</Link></li>
            <li><Link to="/sobre-nos">Sobre Nós</Link></li>
            <li><Link to="/fale-conosco">Fale Conosco</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;