// src\components\Footer\index.jsx

import React from 'react';
import { Link } from 'react-router-dom';
import './styles.css';

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="container footer-grid">
        {/* Coluna 1: Sobre */}
        <div className="footer-column">
          <h3 className="footer-logo">Senai Farmacy</h3>
          <p>
            Sua saúde e bem-estar em primeiro lugar. Um projeto de estudo
            combinando React e Node.js.
          </p>
        </div>

        {/* Coluna 2: Links Rápidos */}
        <div className="footer-column">
          <h4>Links Rápidos</h4>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/servicos">Serviços</Link></li>
            <li><Link to="/sobre-nos">Sobre Nós</Link></li>
            <li><Link to="/fale-conosco">Fale Conosco</Link></li>
          </ul>
        </div>

        {/* Coluna 3: Nossos Serviços */}
        <div className="footer-column">
          <h4>Serviços</h4>
          <ul>
            <li>Aferição de Pressão</li>
            <li>Aplicação de Injetáveis</li>
            <li>Testes Rápidos</li>
            <li>Colocação de Brincos</li>
          </ul>
        </div>

        {/* Coluna 4: Contato */}
        <div className="footer-column">
          <h4>Entre em Contato</h4>
          <ul>
            <li>Rua Fictícia, 123, SP</li>
            <li>(11) 98765-4321</li>
            <li>contato@senaifarmacy.com</li>
          </ul>
        </div>
      </div>

      {/* Copyright */}
      <div className="footer-copyright">
        <div className="container">
          <p>
            © {new Date().getFullYear()} Senai Farmacy. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;