// src\pages\ContactUs\index.jsx

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
// 1. Importa a instância 'api' ao invés do 'axios'
import api from './api'; 
import { ToastContainer, toast } from 'react-toastify';

import 'react-toastify/dist/ReactToastify.css';
import './styles.css';

// O Schema de validação (Yup) permanece o mesmo
const schema = yup.object().shape({
// ... (schema yup sem alterações) ...
  nome: yup
    .string()
    .required('O nome é obrigatório'),
  email: yup
    .string()
    .email('Digite um e-mail válido')
    .required('O e-mail é obrigatório'),
  telefone: yup
    .string()
    .matches(/^\d{10,11}$/, 'Telefone inválido (ex: 11999998888)')
    .required('O telefone com DDD é obrigatório'),
  mensagem: yup
    .string()
    .min(10, 'A mensagem deve ter pelo menos 10 caracteres')
    .required('A mensagem não pode estar vazia'),
}).required();


const ContactUs = () => {
  const [isLoading, setIsLoading] = useState(false);

  const { 
    register, 
    handleSubmit, 
    formState: { errors }, 
    reset 
  } = useForm({
    resolver: yupResolver(schema),
  });

  // 4. Função de Envio adaptada
  const onSubmitForm = async (data) => {
    setIsLoading(true);
    
    // 2. Não precisamos mais da API_URL aqui

    try {
      // 3. Usamos a instância 'api' para fazer a requisição
      await api.post('/api/contatos', data);

      toast.success('Mensagem enviada com sucesso! Obrigado.');
      reset(); 

    } catch (error) {
      console.error('Erro ao enviar formulário:', error);
      toast.error('Houve um erro ao enviar sua mensagem. Tente novamente.');
    
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="contact-container">
      <ToastContainer position="top-right" autoClose={5000} />

      <h1 className="contact-title">Fale Conosco</h1>
      <p className="contact-intro">
        Tem alguma dúvida, sugestão ou reclamação? Preencha o formulário abaixo
        e entraremos em contato.
      </p>

      {/* O Formulário (sem alterações no JSX) */}
      <form onSubmit={handleSubmit(onSubmitForm)} className="contact-form">
        
        {/* Campo Nome */}
        <div className="form-group">
{/* ... (código jsx do formulário sem alterações) ... */}
          <label htmlFor="nome">Nome Completo</label>
          <input
            type="text"
            id="nome"
            {...register('nome')}
            className={errors.nome ? 'input-error' : ''}
          />
          <p className="error-message">{errors.nome?.message}</p>
        </div>

        {/* Campo E-mail */}
        <div className="form-group">
          <label htmlFor="email">E-mail</label>
          <input
            type="email"
            id="email"
            {...register('email')}
            className={errors.email ? 'input-error' : ''}
          />
          <p className="error-message">{errors.email?.message}</p>
        </div>

        {/* Campo Telefone */}
        <div className="form-group">
          <label htmlFor="telefone">Telefone (somente números, com DDD)</label>
          <input
            type="tel"
            id="telefone"
            placeholder="Ex: 11987654321"
            {...register('telefone')}
            className={errors.telefone ? 'input-error' : ''}
          />
          <p className="error-message">{errors.telefone?.message}</p>
        </div>

        {/* Campo Mensagem */}
        <div className="form-group">
          <label htmlFor="mensagem">Mensagem</label>
          <textarea
            id="mensagem"
            rows="6"
            {...register('mensagem')}
            className={errors.mensagem ? 'input-error' : ''}
          />
          <p className="error-message">{errors.mensagem?.message}</p>
        </div>

        {/* Botão de Envio (com estado de loading) */}
        <button type="submit" className="submit-button" disabled={isLoading}>
          {isLoading ? 'Enviando...' : 'Enviar Mensagem'}
        </button>
      </form>
    </main>
  );
};

export default ContactUs;