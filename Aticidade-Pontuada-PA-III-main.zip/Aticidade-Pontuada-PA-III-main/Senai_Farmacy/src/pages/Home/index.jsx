// src\pages\Home\index.jsx

import React from 'react';
import { Link } from 'react-router-dom';
import './styles.css';

const Home = () => {
  return (
    <main className="home-container">
      {/* Seção do Banner/Hero, conforme solicitado */}
      <section className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">Bem-vindo à Senai Farmacy</h1>
          <p className="hero-subtitle">
            Sua saúde e bem-estar em primeiro lugar. Encontre os melhores
            serviços e produtos aqui.
          </p>
          <div className="hero-ctas">
            {/* CTA para "Serviços" */}
            <Link to="/servicos" className="cta-button primary">
              Nossos Serviços
            </Link>
            {/* CTA para "Fale Conosco" */}
            <Link to="/fale-conosco" className="cta-button secondary">
              Fale Conosco
            </Link>
          </div>
        </div>
      </section>

      {/* Você pode adicionar mais seções aqui, como "Mais Populares", etc. */}
    </main>
  );
};

export default Home;