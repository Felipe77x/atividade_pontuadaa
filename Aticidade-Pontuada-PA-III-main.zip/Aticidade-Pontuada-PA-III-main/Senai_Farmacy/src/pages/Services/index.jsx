import React from 'react';
import './styles.css';

// Dados dos serviços (poderiam vir de uma API no futuro)
const servicesData = [
  {
    title: 'Aferição de Pressão Arterial',
    description: 'Monitoramento da pressão arterial com equipamentos calibrados e profissionais treinados para um acompanhamento preciso.',
  },
  {
    title: 'Aplicação de Injetáveis',
    description: 'Administração segura de medicamentos injetáveis (com prescrição médica), seguindo todas as normas de assepsia.',
  },
  {
    title: 'Testes Rápidos',
    description: 'Realização de testes rápidos, como Glicemia (diabetes), COVID-19 (Antígeno e Anticorpos) e outros exames laboratoriais rápidos.',
  },
  {
    title: 'Colocação de Brincos',
    description: 'Perfuração de orelha segura e higiênica, utilizando material esterilizado e descartável.',
  },
];

const Services = () => {
  return (
    <main className="services-container">
      <h1 className="services-title">Nossos Serviços</h1>
      <p className="services-intro">
        Conheça os serviços farmacêuticos que oferecemos para cuidar da sua saúde
        e bem-estar.
      </p>

      <div className="services-list">
        {servicesData.map((service, index) => (
          <div key={index} className="service-item">
            <h3>{service.title}</h3>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </main>
  );
};

export default Services;