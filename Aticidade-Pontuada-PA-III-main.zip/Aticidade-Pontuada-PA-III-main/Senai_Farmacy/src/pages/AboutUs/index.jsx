// src\pages\AboutUs\index.jsx

import React from 'react';
import './styles.css';

const AboutUs = () => {
  return (
    <main className="about-container container">
      {/* Seção Superior (como no design) */}
      <section className="about-intro-section">
        <h2>
          Senai Farmacy é um projeto de estudo focado em
          <span> 35 anos de experiência</span> (fictícia)
          focando em valor e qualidade.
        </h2>
      </section>

      {/* Seção de Grid (Imagem + Texto) */}
      <section className="about-grid-section">
        <div className="about-grid-image">
          {/* Imagem de placeholder */}
          <img 
            src="https://placehold.co/600x450/e0e0e0/333?text=Laboratorio&font=inter" 
            alt="Laboratório" 
          />
        </div>
        <div className="about-grid-content">
          <h3>Bem-vindo à Senai Farmacy Inc.</h3>
          <h4>Ter um novo nome é apenas o começo.</h4>
          <p>
            Fundada em 2024, a Senai Farmacy nasceu de um projeto acadêmico com a
            missão de ir além da simples venda de medicamentos.
          </p>
          <p>
            Nosso objetivo sempre foi criar um espaço de saúde acessível,
            combinando tecnologia de ponta com um atendimento humano e
            personalizado.
          </p>
          <a href="#more" className="about-link">
            SAIBA MAIS SOBRE NÓS →
          </a>
        </div>
      </section>

      {/* Seção de Valores (Missão, Visão, etc.) */}
      <section className="values-section">
        <div className="value-item">
          <h4>Missão</h4>
          <p>Prover saúde e bem-estar à comunidade.</p>
        </div>
        <div className="value-item">
          <h4>Visão</h4>
          <p>Ser a farmácia de referência em inovação.</p>
        </div>
        <div className="value-item">
          <h4>Valores</h4>
          <p>Compromisso, Ética, Inovação e Empatia.</p>
        </div>
      </section>
    </main>
  );
};

export default AboutUs;