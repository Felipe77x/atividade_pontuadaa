import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Importa os componentes de layout
import Header from './components/Header';
import Footer from './components/Footer';
// Importa as Páginas
import Home from './pages/Home';
import Services from './pages/Services';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';

// Importa o CSS global/app (necessário para o layout)
import './App.css';

function App() {
  return (
    <div className="app-container">
      {/* O Header fica fora do Routes, aparecendo em todas as páginas */}
      <Header />

      {/* O 'content-wrap' é o container para o conteúdo da página atual */}
      <main className="content-wrap">
        <Routes>
          {/* Define a rota para cada página */}
          <Route path="/" element={<Home />} />
          <Route path="/servicos" element={<Services />} />
          <Route path="/sobre-nos" element={<AboutUs />} />
          <Route path="/fale-conosco" element={<ContactUs />} />

          {/* Opcional: Rota "Não Encontrado" (404) */}
          <Route path="*" element={<h1 style={{ textAlign: 'center', margin: '2rem' }}>404: Página não encontrada</h1>} />
        </Routes>
      </main>

      {/* O Footer também fica fora do Routes */}
      <Footer />
    </div>
  );
}

export default App;