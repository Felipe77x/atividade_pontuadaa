import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

// Importa o CSS global
import './App.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* O BrowserRouter deve envolver o App */}
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
);