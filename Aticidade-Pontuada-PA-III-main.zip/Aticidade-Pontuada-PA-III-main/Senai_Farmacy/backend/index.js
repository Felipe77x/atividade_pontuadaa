// backend\index.js

const express = require('express');
const cors = require('cors');
const { Sequelize, DataTypes } = require('sequelize');
const app = express();

const sequelize = new Sequelize('service_api_db', 'root', "", {
    host: 'localhost',
    dialect: 'mysql'
});

const Contatos = sequelize.define('Contatos', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    telefone: {
        type: DataTypes.STRING,
        allowNull: false
    },
    mensagem: {
        type: DataTypes.TEXT,
        allowNull: false
    }
}, {
    tableName: 'contatos',
    timestamps: false
});

app.use(cors());
app.use(express.json());

const PORT = 3000;

app.get('/api/contatos', async (req, res) => {
    try {
        const contatos = await Contatos.findAll();
        res.json(contatos);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar os contatos.' });
    }
});

app.post('/api/contatos', async (req, res) => {
    const { nome, email, telefone, mensagem } = req.body;
    try {
        await Contatos.create({ nome, email, telefone, mensagem });
        res.status(201).json({ message: 'Contato salvo com sucesso!' });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao salvar o contato.' });
    }
});

sequelize.sync().then(() => {
    app.listen(PORT, () => {
        console.log(`🔌Servidor rodando na porta ${PORT}`);
        console.log('🚀 Conectado ao banco de dados MySQL');
    });
}).catch((error) => {
    console.error('❌ Erro ao conectar ao banco de dados:', error);
});